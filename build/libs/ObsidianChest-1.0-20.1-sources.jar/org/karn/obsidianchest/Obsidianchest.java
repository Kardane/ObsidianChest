package org.karn.obsidianchest;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;

public class Obsidianchest implements ModInitializer {
    public static class_1928.class_4313<class_1928.class_4310> OBSIDIANCHEST;

    @Override
    public void onInitialize() {
        OBSIDIANCHEST = GameRuleRegistry.register("enableObsidianChest", class_1928.class_5198.field_24097, GameRuleFactory.createBooleanRule(false));
    }
}
