package org.karn.obsidianchest.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import static org.karn.obsidianchest.Obsidianchest.OBSIDIANCHEST;

@Mixin(class_1927.class)
public class ExplosionMixin {
    @Shadow
    private class_3218 world;

    @ModifyExpressionValue(
            method = "collectBlocksAndDamageEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;isInBuildLimit(Lnet/minecraft/util/math/BlockPos;)Z")
    )
    private boolean onlyFlyIfAllowed(boolean original,@Local(ordinal = 0) class_2338 blockPos) {
        if(world.method_8450().method_8355(OBSIDIANCHEST) && world.method_8321(blockPos) != null) {
            return false;
        }
        return original;
    }
}
